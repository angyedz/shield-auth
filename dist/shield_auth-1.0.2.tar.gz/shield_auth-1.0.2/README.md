# 🛡️ Shield-Auth

[![PyPI version](https://img.shields.io/pypi/v/shield-auth.svg)](https://pypi.org/project/shield-auth/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/shield-auth.svg)](https://pypi.org/project/shield-auth/)
[![Downloads](https://img.shields.io/pypi/dm/shield-auth)](https://pypi.org/project/shield-auth/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

**Shield-Auth** — профессиональная Python-библиотека для создания систем регистрации и авторизации. Идеальное решение для проектов, где важна безопасность, но нет необходимости в тяжелых базах данных. Все данные надежно защищены и хранятся в простом текстовом файле.

## ✨ Особенности

- 🔐 **Надежное хеширование** с использованием bcrypt
- 🧂 **Уникальная соль** для каждого пароля
- 📁 **Работа с текстовым файлом** — не требуется СУБД
- 🚀 **Простой API** — всего 2 основных метода
- 🛡️ **Защита от атак** — перебора и словарных атак
- 🐍 **Python 3.8+** — поддержка современных версий Python

## 📦 Установка

Установите библиотеку через pip:

```bash
pip install shield-auth


📚 ПОЛНАЯ ДОКУМЕНТАЦИЯ (API Reference)
1. Подключение и инициализация
Класс PasswordManager — это основная точка входа. При создании объекта библиотека проверяет наличие файла базы данных и, если его нет, создает его автоматически.

Python
from shield import PasswordManager

# Аргумент db_file: путь к вашему .txt файлу с аккаунтами
db = PasswordManager(db_file="accounts.txt")
2. Регистрация пользователя: register_user(login, password)
Метод для создания новой учетной записи. Использует алгоритм bcrypt с адаптивной солью.

Параметры:

login (string): Уникальное имя пользователя.

password (string): Пароль в открытом виде.

Возвращаемое значение (dict):

{"status": "success", "message": "..."} — если регистрация прошла успешно.

{"status": "error", "message": "..."} — если логин уже занят или произошла ошибка записи.

Пример:

Python
res = db.register_user("admin_user", "my_secure_password_2026")
print(res["message"])
3. Авторизация (Проверка): check_user(login, password)
Метод для проверки введенных данных при входе. Сравнивает присланный пароль с зашифрованным хешем в базе.

Параметры:

login (string): Логин пользователя.

password (string): Пароль для проверки.

Возвращаемое значение (bool):

True: Логин существует и пароль верен.

False: Ошибка в логине или пароле.

Пример:

Python
if db.check_user("admin_user", "my_secure_password_2026"):
    print("Доступ открыт!")
else:
    print("Неверные данные.")
🔒 БЕЗОПАСНОСТЬ (How it works)
Библиотека разработана с учетом современных требований к кибербезопасности:

Хеширование: Мы не храним пароли. Мы храним их необратимые отпечатки (хеши).

Соль (Salt): К каждому паролю добавляется уникальная соль, что защищает от взлома через Rainbow Tables.

Bcrypt: Используется алгоритм с 12 раундами вычислений, что делает брутфорс (перебор) паролей практически невозможным.

🌐 ПРИМЕР С ИСПОЛЬЗОВАНИЕМ FLASK (BACKEND)
Python
from flask import Flask, request, jsonify
from shield import PasswordManager

app = Flask(__name__)
auth_system = PasswordManager("database.txt")

@app.route('/auth', methods=['POST'])
def handle_auth():
    data = request.json
    mode = data.get('mode') # 'reg' или 'login'
    user = data.get('user')
    pwd = data.get('pwd')

    if mode == 'reg':
        return jsonify(auth_system.register_user(user, pwd))
    
    if auth_system.check_user(user, pwd):
        return jsonify({"status": "success", "user": user})
    
    return jsonify({"status": "error", "message": "Invalid credentials"}), 401

if __name__ == '__main__':
    app.run(port=8080)
📄 ЛИЦЕНЗИЯ
Проект распространяется под лицензией MIT. Вы можете использовать его в любых целях.